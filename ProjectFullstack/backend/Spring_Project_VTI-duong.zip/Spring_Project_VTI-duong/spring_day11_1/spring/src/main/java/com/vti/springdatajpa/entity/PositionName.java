package com.vti.springdatajpa.entity;

public enum PositionName {
    DEV, TEST, SCRUM_MASTER, PM;
}
