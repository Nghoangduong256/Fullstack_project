package com.vti.springdatajpa.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DepartmentServiceImplTest {

    @Test
    void getAllDepartments() {
    }

    @Test
    void createDepartment() {
    }
}